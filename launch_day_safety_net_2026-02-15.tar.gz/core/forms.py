from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

class CertificateSignupForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(
        max_length=30, 
        required=True,
        # help_text moved here and font size increased to 1rem
        help_text="<span class='text-warning' style='font-size: 1rem;'><i class='bi bi-exclamation-triangle-fill'></i> IMPORTANT: Enter Your Name Exactly As It Will Appear On Your Certificate.</span>"
    )
    email = forms.EmailField(required=True, label="Email Address")

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')

    # THE FIX: This runs BEFORE the database save
    def clean_email(self):
        email = self.cleaned_data.get('email')
        # Check if this email is already a username or an email address in the system
        if User.objects.filter(email=email).exists() or User.objects.filter(username=email).exists():
            raise ValidationError("This email is already registered. Please log in instead.")
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.username = self.cleaned_data['email'] # Sets Email as the Login ID
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        
        if commit:
            user.save()
        return user
