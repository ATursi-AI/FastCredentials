from django.contrib.sitemaps.views import sitemap
from core.sitemaps import StaticViewSitemap, CourseSitemap
from django.views.generic import TemplateView
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from core import views

# Define which maps we want to show
sitemaps = {
    'static': StaticViewSitemap,
    'courses': CourseSitemap,
}

urlpatterns = [
    # Admin
    path('bluenala1/', admin.site.urls),
    path('sitemap.xml', sitemap, {'sitemaps': sitemaps}, name='django.contrib.sitemaps.views.sitemap'),

    # SEO
    path('robots.txt', TemplateView.as_view(template_name="robots.txt", content_type="text/plain")),

    # Authentication (Login/Logout/Signup)
    path('signup/', views.signup, name='signup'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(), name='logout'),
    
    # Password Reset (The 4 Steps)
    path('reset_password/', auth_views.PasswordResetView.as_view(template_name='password_reset.html'), name='reset_password'),
    path('reset_password_sent/', auth_views.PasswordResetDoneView.as_view(template_name='password_reset_sent.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_form.html'), name='password_reset_confirm'),
    path('reset_password_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_done.html'), name='password_reset_complete'),

    # Main Pages
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('terms/', views.terms, name='terms'),
    path('about/', views.about, name='about'),
    path('support/', views.support, name='support'),
    path('powered-by-ai/', views.ai_monitoring, name='ai_monitoring'),

    # Course Flow
    path('course/<int:course_id>/', views.course_detail, name='course_detail'),
    path('course/<int:course_id>/quiz/', views.take_quiz, name='take_quiz'),

    # Certificates
    path('certificate/<str:cert_id>/', views.certificate_view, name='certificate_view'),
    path('verify/<str:cert_id>/', views.verify_certificate, name='verify_certificate'),

    # Payments
    path('checkout/<int:course_id>/', views.create_checkout_session, name='create_checkout_session'),
    path('payment/success/', views.payment_success, name='payment_success'),
    path('payment/cancel/', views.payment_cancel, name='payment_cancel'),
]
